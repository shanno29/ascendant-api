Copy files in this folder (except this README) to C:\Program Files (x86)\MusicBee\Plugins. To verify, open MusicBee > Edit > Preferences. Under "Plugins", ensure "vibetribe plugin" appears and is enabled.

In future releases, this install will happen automatically.